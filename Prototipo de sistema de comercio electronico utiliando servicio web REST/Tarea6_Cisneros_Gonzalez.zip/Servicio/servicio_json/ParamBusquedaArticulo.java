package servicio_json;

public class ParamBusquedaArticulo
{
  String palabraClave;
  int orden;
}
