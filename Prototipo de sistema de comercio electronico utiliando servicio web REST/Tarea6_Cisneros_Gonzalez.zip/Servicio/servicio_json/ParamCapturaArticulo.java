package servicio_json;

public class ParamCapturaArticulo 
{
  Articulo articulo;
}
