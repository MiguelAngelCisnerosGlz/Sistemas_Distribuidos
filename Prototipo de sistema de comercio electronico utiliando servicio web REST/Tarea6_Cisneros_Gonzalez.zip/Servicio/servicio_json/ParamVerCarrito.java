package servicio_json;

    public class ParamVerCarrito {
        private int userId;
    
        public ParamVerCarrito() {}
    
        public ParamVerCarrito(int userId) {
            this.userId = userId;
        }
    
        public int getUserId() {
            return userId;
        }
    
        public void setUserId(int userId) {
            this.userId = userId;
        }
    }
    
