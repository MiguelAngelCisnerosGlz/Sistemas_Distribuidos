
package servicio_json;

public class ParamConsultaArticulos 
{
  String palabra;
  int orden;
}
