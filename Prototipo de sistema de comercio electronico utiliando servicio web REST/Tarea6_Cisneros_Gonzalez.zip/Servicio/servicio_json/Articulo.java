
package servicio_json;

public class Articulo
{
  String nombre;
  String descripcion;
  float precio;
  int existencia;
  int relevancia;
  byte[] foto;
}
