package servicio_json;

class ArticuloCarrito {
    int idArticulo;
    String nombre;
    String descripcion;
    float precio;
    int cantidad;
    byte[] foto;
}
