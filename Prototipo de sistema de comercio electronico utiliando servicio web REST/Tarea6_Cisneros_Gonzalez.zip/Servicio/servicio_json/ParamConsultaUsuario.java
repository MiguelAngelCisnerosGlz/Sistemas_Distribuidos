/*
  Carlos Pineda Guerrero, marzo 2024
*/

package servicio_json;

public class ParamConsultaUsuario 
{
  String email;
}
